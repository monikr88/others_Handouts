import configparser
from dataclasses import dataclass
from dataclasses import field
from pathlib import Path

@dataclass
class Configuration:
    # configuration: str = field(default_factory=str)
    """
    Configuration class list the path to configuration file
    """
    # PDFs_XML\\ not necessary for .exe
    config_path: Path = Path('config\\config.ini')

    def get_config(self):
        """
        Function to get the configuration file

        Returns:
            ConfigParse: object configParse
        """
        try:
            conf = configparser.ConfigParser()
            conf.read(self.config_path, encoding='utf-8') #._sections # dict#
            return conf
        except Exception as e:
            print(f'Error: {e}')
        
    def get_output_setup(self):
        """
        Function to find values from config.ini to find 
        local pdfs and write the renamed files in outputs folder.

        Returns:
            str: csv file name
        """
        try:
            config = configparser.ConfigParser()
            config.read(self.config_path, encoding='utf-8') #._sections # dict#
            #return (config["system_conf"]["pdfs_path"], 
            return config["system_conf"]["output_file_name"]
        except Exception as e:
            print(f'Error: {e}')