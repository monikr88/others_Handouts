""""
This code simply calls main function from app.py,
which will do all the job
"""
from .app import main

main()

# With Streamlit and cx_freeze this file is not needed anymore