from tkinter import filedialog
import streamlit.runtime.scriptrunner.magic_funcs
import streamlit
import streamlit.web.cli as stcli
import sys
import reader
import tools 
import writer 
import extraction

def streamlit_run():
     sys.argv=["streamlit", "run", "Accueil.py", "--global.developmentMode=false"]
     sys.exit(stcli.main())

if __name__ == "__main__":
     streamlit_run()
 
# to run the web app
# go inside folder PDFs_XML on the console(terminal)
# cxfreeze -c run.py