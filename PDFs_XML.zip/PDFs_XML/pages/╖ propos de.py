import streamlit as st
import app

lang_options = {
                    "Français (FR)":"fr_FR",
                    "English (US)":"en_US"
            }

st.set_page_config(
        page_title="Espace Metrologie",
)

locale = st.radio(label='Language', options=list(lang_options.keys()), horizontal=True)
# Note we use the selected human-readable locale to get the relevant
# ISO locale code from the lang_options dictionary.
lang_dict = app.load_bundle(lang_options[locale])
    
st.markdown(lang_dict["about"])