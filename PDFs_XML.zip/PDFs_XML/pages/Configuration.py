import streamlit as st
import tkinter as tk
from tkinter import filedialog
import pandas as pd

from logging import Logger

from reader import get_XML, app_read_section_keys
from tools import Configuration
from writer import save_config
from extraction import AssignmentSolver
import app

# https://streamlit.io/
# https://cheat-sheet.streamlit.app/

#to construct basic graphical user interface (GUI) applications.
root = tk.Tk()
  
def file_selector(pkey):   
        """
        This is a function to select file from local computer

        Args:
            pkey (str): name to assing to the component

        Returns:
            list: list of files uploaded
        """
        
        # https://docs.streamlit.io/library/api-reference/widgets/st.file_uploader
        files = st.file_uploader("Pick a file", type=("pdf"), accept_multiple_files=True, key=pkey)
        
        # to delete files duplicated. Streamlit does not have a form to clean the uploaded files yet!
        check_val = set()      #Check Flag
        res = []
        for i in files:
                if i.name not in check_val:
                        res.append(i)
                        check_val.add(i.name)   
        
        return res      

def __get_XML(pdfs, path="data\\outputs\\streamlit\\"): 
        """
        Internal function to generate the XMl files. It 
        calls the reader module to read the PDF.
        Args:
            pdfs (list): list of files to convert to XML
            path (str, optional): Path where the XML files are 
            going to be saved. Defaults to "data\outputs\streamlit\".
        """
        st.write('You have selected `%s`' % path)
        for f in pdfs:
                tree = get_XML(f)
                #path = ''.join(f.split('\\')[:-1])  # ' '.join(content.split(' ')[:-1])
                st.write("filename:", path + str(f.name))
                # https://github.com/zahir2000/pdf-query-streamlit/blob/master/app.py
                tree.write(path + str(f.name) + '.xml', pretty_print = True, )
      
def __config_values(input_values):
        """
        This function converts the list of inputs values 
        [field, separator, index, len] into a dictionary to 
        save these configuration values separated by comma
        
        Args:
            input_values (list): list of fields to be used 
            to clean the data extracted

        Returns:
            _type_: returns a dictionary as: 
            {
                {"fields": "XXX,XXX,XXX,XXX"},
                {"separator": "-" }
            }
        """
        fields= {}
        field = []
        separator = []
        index = []
        len = []
        for t in input_values: # list of tuples
                field.append(t[0])
                separator.append(t[1])
                index.append(t[2])
                len.append(t[3])
        # into dict
        fields["field"] = "\",\"".join(field)
        fields["separator"] = '\",\"'.join(separator)
        fields["index"] = ",".join(index)
        fields["len"] = ",".join(len)
        return fields
   
def add_fields(i, lang_dict):
        """
        This function adds inputs: field, separator, index and length
        depending on the number of values required to extract to rename 
        the file.

        Args:
            i (int): number of values required to extract 
            lang_dict (dict): language file to translate labels into French or English

        Returns:
            tuple: returns the values (field, separator, index, length) typed by the user.
        """
        st.write(f":blue[_{lang_dict['tab4_w16']}{i}_]")
        field = st.text_input(lang_dict['tab4_t_i8'], 
                                key=f"field_{i}", 
                                placeholder=lang_dict['tab4_t_place'])
        
        st.caption(f":blue[_{lang_dict['tab4_capt_p1']}_] :C {lang_dict['tab4_capt_p2']}")
        
        separator = st.text_input(lang_dict['tab4_t_i5'], 
                                key=f"sep_{i}", 
                                placeholder=lang_dict["tab4_t_i5_place"], 
                                help=lang_dict["tab4_t_i5_help"])
        
        index = st.text_input(lang_dict["tab4_t_i6"], 
                                key=f"ind_{i}", 
                                placeholder=lang_dict["tab4_t_i6_place"], 
                                help=lang_dict["tab4_t_i6_help"])  
        
        len = st.text_input(lang_dict["tab4_t_i7"], 
                                key=f"len_{i}", 
                                placeholder=lang_dict["tab4_t_i7_place"])
        
        return field, separator, index, len

def get_section_keys():
        """
        This function gets the current sections in the config.ini file.
        It calls the reader module to read the config.ini.

        Returns:
            dict: keys present in the config file
        """
        print("app - Reading config.ini")
        config = Configuration()
        config = config.get_config()
        return app_read_section_keys(config)

def test_new_config(pdfs, key:str, key_coord:str, company_name:str, 
                    pdf_title:str, year:str, input_values:list,
                    uncertainty:str) -> dict:
        """
        This function is to test a new configuration with a few sample files

        Args:
            pdfs (list): list of files uploaded
            key (str): name of the key (section)
            key_coord (str): coordinates where the key is located in the XML file
            company_name (str): name of the company. First part of the file name
            input_values (list): field, separator, index and length of each input
            year (str): coordinates where the year is located in the XML file

        Returns:
            dict: list of new file names
        """
        # creates config in dict format
        fields = __config_values(input_values)
        
        # creates configuration in memory
        config = save_config(key, key_coord, company_name, pdf_title, fields, year, uncertainty, write=False)
        
        # returns new name 
        return app.simulation(pdfs, config)

def main():
        """
        Main function to create HTML view and to call logic functions.
        """
        lang_options = {
                "Français (FR)":"fr_FR",
                "English (US)":"en_US"
        }
        
        st.set_page_config(
                page_title="Configuration",
        )
        
        locale = st.radio(label='Language', options=list(lang_options.keys()), horizontal=True)
        # Note we use the selected human-readable locale to get the
        # relevant ISO locale code from the lang_options dictionary.
        lang_dict = app.load_bundle(lang_options[locale])
        
        # HTML page      
        st.title(lang_dict['title_config'])
        
        # Insert containers separated into tabs:
        name_tab_uploadF = lang_dict['name_tab_uploadF']
        name_tab_XML = lang_dict['name_tab_XML']
        name_tab_configuration = lang_dict['name_tab_configuration']
        name_tab_simulation = lang_dict['name_tab_simulation']

        tab2, tab3, tab4, tab5 = st.tabs([f"{name_tab_uploadF}", 
                                f"{name_tab_XML}", 
                                f"{name_tab_configuration}",
                                f"{name_tab_simulation}"])
        
        tab2.write(lang_dict["tab2"])
        tab3.write(lang_dict["tab3"])
        tab4.write(lang_dict["tab4"])
        tab5.write(lang_dict["tab5"]) # Simulation of file renaming
      
        with tab2: # Upload files
                st.header(lang_dict["how_it_works"])
                st.write(lang_dict["tab2_w1"])
                st.write(f'2. {lang_dict["tab2_on_tab"]}"{name_tab_XML}"{lang_dict["tab2_w2_p2"]}')
                st.write(f'3. {lang_dict["tab2_on_tab"]}"{name_tab_configuration}"{lang_dict["tab2_w4_p2"]} {lang_dict["tab2_w3_p2"]}')

                st.header(lang_dict["tab2_h2"])
                pdfs = file_selector(pkey='pdfs')

        with tab3: # XMLs
                st.header(lang_dict["how_it_works"])
                st.write(f'{lang_dict["tab3_w1_p1"]}"{name_tab_uploadF}"{lang_dict["tab3_w1_p2"]}')
                st.write(f'{lang_dict["tab3_w2_p1"]}"{name_tab_XML}"{lang_dict["tab3_w2_p2"]}')
                st.write(lang_dict["tab3_w3"])
                st.write(lang_dict["tab3_w4"])
                
                st.subheader(lang_dict["tab3_sh1"])
                st.write(lang_dict["tab3_w5"])
                st.write(lang_dict["tab3_w6"])
                
                st.image("resources/images/bbox.png")
                root.withdraw()

                # Make folder picker dialog appear on top of other windows
                root.wm_attributes('-topmost', 1)
                dirname= ""
                st.header(lang_dict["get_xml"])
                st.write(lang_dict["tab3_w7"])
                clicked = st.button(lang_dict["get_xml"])
                if clicked:
                        dirname = st.text_input(lang_dict["tab3_t_i1"], filedialog.askdirectory(master=root)) + "/"
                        __get_XML(pdfs, dirname)
                        st.success(lang_dict["tab5_success"])

        with tab4: # Configuration
                st.header(lang_dict["how_it_works"])
                st.write(lang_dict["tab4_w1"])
                st.write(f':red[ {lang_dict["tab4_w2"]}"{name_tab_simulation}"]')

                st.subheader(lang_dict["tab4_sh1"])
                st.write(f'{lang_dict["tab4_w3_p1"]}"{name_tab_simulation}"{lang_dict["tab4_w3_p2"]}')
                
                if st.button(lang_dict["tab4_b1"]): # Show liste
                        sects = get_section_keys()                        
                        df = pd.DataFrame(sects, columns=(lang_dict["tab4_c1"], #"Company's Name (Display name)",
                                                          lang_dict["tab4_c2"], #"Key (value inside XML)",
                                                          lang_dict["tab4_c3"])) #"Report Type (Title inside PDF) "))
                        st.table(df)

                st.subheader(lang_dict["tab4_sh2"])      
                st.write(lang_dict["tab4_w4"])
                
                st.image('resources/images/config.png')
                st.write(lang_dict["tab4_w5"])
                st.header(lang_dict["tab4_sh3"])
                st.write(lang_dict["tab4_w6"])
                st.write(lang_dict["tab4_w7"])
                st.write(lang_dict["tab4_w8"])
                st.write(lang_dict["tab4_w9"])
                st.write(lang_dict["tab4_w10"])
                st.write(lang_dict["tab4_w11"])
                
                company_name = st.text_input(lang_dict["tab4_t_i1"],
                                        placeholder=lang_dict["tab4_t_i1_place"])
                
                pdf_title = st.text_input(lang_dict["tab4_t_i9"],
                                        placeholder=lang_dict["tab4_t_i9_place"])
                
                pdf_title = pdf_title.split("\"")[0] # truncate if "
                
                key = st.text_input(lang_dict["tab4_t_i2"], 
                                placeholder=lang_dict["tab4_t_place"],
                                help=lang_dict["tab4_t_i2_help"])
                
                title = st.text_input(lang_dict["tab4_t_i3"], 
                                placeholder=lang_dict["tab4_t_place"],
                                help='')
                
                year = st.text_input(lang_dict["tab4_t_i4"], 
                                placeholder=lang_dict["tab4_t_place"],
                                help='')
                
                uncertainty = st.text_input(lang_dict["tab4_t_i10"], 
                                placeholder=lang_dict["tab4_t_place"],
                                help='')
                
                #https://discuss.streamlit.io/t/how-to-add-more-fields-based-on-user-input/31558/2
                number_inputs = st.number_input(lang_dict["tab4_n_i"], 
                                                step=1, min_value=1,
                                                help=lang_dict["tab4_n_i_help"])
                
                input_values = [add_fields(i+1, lang_dict)
                                for i in range(number_inputs)]
                
                #### TEST THE CONFIGURATION!!!! before saving
                st.subheader(lang_dict["tab4_sh4"])
                st.write(lang_dict["tab4_w12"])
                st.write(f'{lang_dict["tab4_w13_p1"]}{name_tab_uploadF}{lang_dict["tab4_w13_p2"]}')
                
                st.write(lang_dict["tab5_w3"])
                        
                if(st.button(lang_dict["tab4_b2"])): # TEST
                        with st.spinner(lang_dict["wait_for_it"]):
                                solution = test_new_config(pdfs, key, title, company_name, 
                                                           pdf_title, year, input_values, uncertainty)
                                st.write("Final:", solution)
                                
                                st.write(f'{lang_dict["tab5_w4_p1"]}')
                        
                #### Saves the configuration
                st.subheader(lang_dict["tab4_sh5"])
                if(st.button(lang_dict["tab4_b3"])): # SAVE
                        fields = __config_values(input_values)
                        saved = save_config(key, title, company_name, pdf_title, fields, year, uncertainty)
                        
                        if saved:
                                st.write(f":green[{lang_dict['tab4_w14']}]")
                        else:
                                st.write(f':red[{lang_dict["tab4_w15_p1"]}"{key}"{lang_dict["tab4_w15_p2"]}]')

        with tab5: # Simulation of file renaming
                st.header(lang_dict["how_it_works"])
                st.write(lang_dict["tab5_w4"])
                st.write(f'{lang_dict["tab5_w1_p1"]}"{name_tab_uploadF}"{lang_dict["tab5_w1_p2"]}')
                st.write(f'{lang_dict["tab5_w2_p1"]}"{name_tab_simulation}"{lang_dict["tab5_w2_p2"]}')
                st.write(lang_dict["tab5_w3"])
                st.write(f":red[_{lang_dict['tab5_w5']}_]")
                
                with st.spinner(lang_dict["wait_for_it"]):
                        if(st.button(f'{name_tab_simulation}')): # rename
                                solution = app.simulation(pdfs)
                                st.write("Final:", solution)
                                # https://github.com/zahir2000/pdf-query-streamlit/blob/master/app.py
                                #tree.write(path + str(f.name) + '.xml', pretty_print = True, )
                                st.success(lang_dict["tab5_success"])

if __name__ == "__main__":
        main()

# https://docs.streamlit.io/get-started/tutorials/create-a-multipage-app