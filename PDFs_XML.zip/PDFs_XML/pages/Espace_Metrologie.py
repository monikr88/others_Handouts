import streamlit as st
import app
import tkinter as tk
from tkinter import filedialog
import os
import math
import time
from datetime import datetime

root = tk.Tk()
def main():
    """
    Main function to create HTML view and to call logic functions.
    """
    lang_options = {
                    "Français (FR)":"fr_FR",
                    "English (US)":"en_US"
            }

    st.set_page_config(
        page_title="Espace Metrologie",
    )

    locale = st.radio(label='Language', options=list(lang_options.keys()), horizontal=True)
    # Note we use the selected human-readable locale to get the relevant
    # ISO locale code from the lang_options dictionary.
    lang_dict = app.load_bundle(lang_options[locale])

    # HTML page      
    st.title(lang_dict['title_metro'])
    name_tab_rename = lang_dict['name_tab_rename']
    
    root.withdraw()
    # Make folder picker dialog appear on top of other windows
    root.wm_attributes('-topmost', 1)
                
    dirname_inputs=""
    dirname_outputs=""
    
    st.header(lang_dict["how_it_works"])
    st.write(f"{lang_dict['espace_w1']} '{name_tab_rename}' {lang_dict['espace_w2']}")
    st.write(lang_dict["espace_w4"]) 
    st.write(lang_dict["espace_w5"]) 
            
    #print(dirname_inputs, dirname_outputs)
    st.write(f":blue[{lang_dict['espace_w3']}]")

    with st.spinner(lang_dict["wait_for_it"]):
        if(st.button(f'{name_tab_rename}')): # rename
            dirname_inputs = st.text_input(lang_dict["tab3_t_i1"], filedialog.askdirectory(master=root), key="input") + "/"     
            dirname_outputs = st.text_input(lang_dict["tab3_t_i1"], filedialog.askdirectory(master=root), key="output") + "/"
           
            # get the start time
            start = time.time()
           
            context= app.main(os.path.abspath(os.path.join(dirname_inputs)))
            #path = ''.join(f.split('\\')[:-1])  # ' '.join(content.split(' ')[:-1])
            len_files = len(context.pdfs)
            if len_files > 25:
                st.write(f"{lang_dict['espace_w6']} {len_files} {lang_dict['espace_w7']} {math.ceil(len_files/25)}")
                          
            list1=[]
            for i in range(0, len(context.pdfs), 25):
                solution = app.chunks(context.pdfs[i:i + 25], context.sections, dirname_outputs)
                st.success(f"Chunk {math.ceil((i+1)/25)}/{math.ceil(len_files/25)}")
                list1.append([k for k in solution if list(k.values())[0]['new_name'] == "File not recognized."])
               
            # To display errors 
            if len(list1) > 0:
                st.write(lang_dict['espace_w8'])
                st.write(list1)
                
            st.success(lang_dict["tab5_success"])
            et = time.time()            
            elapsed_time = et - start # get the execution time
            now = datetime.now()
            elapsed = f'Execution time: {float("{:.2f}".format(elapsed_time/60))} minutes. End time: {now.strftime("%H:%M:%S")  }'
            print(elapsed)
            st.write(elapsed)

if __name__ == "__main__":
    main()
    

