import streamlit as st
import app

def main():
    """
    Main function to create HTML view and to call logic functions.
    """
    #st.write("# Welcome to Streamlit! 👋")
    lang_options = {
                    "Français (FR)":"fr_FR",
                    "English (US)":"en_US"
            }

    lang_dict = app.load_bundle("fr_FR")
    #st.session_state.icon = st.session_state.icon_input
        
    st.set_page_config(
        page_title= lang_dict["home_page"],
        page_icon="👋",
    )

    locale = st.radio(label='Language', options=list(lang_options.keys()), horizontal=True)
    #locale = st.sidebar.selectbox(label='Language', options=list(lang_options.keys()))
    # Note we use the selected human-readable locale to get the relevant
    # ISO locale code from the lang_options dictionary.
    lang_dict = app.load_bundle(lang_options[locale])
    
    st.session_state.title = lang_dict["home_page"] #st.session_state.title_input

    # HTML page      
    st.title(lang_dict['title'])

    # Insert containers separated into tabs:
    #get_started = lang_dict["get_started"]
    name_tab_uploadF = lang_dict['name_tab_uploadF']
    name_tab_XML = lang_dict['name_tab_XML']
    name_tab_configuration = lang_dict['name_tab_configuration']
    name_tab_rename = lang_dict['name_tab_rename']

    #tab1 =  st.tabs(f"{get_started}")

    st.header(lang_dict["get_started"])

    # Get Started
    st.write(lang_dict["tab1_w1"])
    st.markdown(f':blue[_{lang_dict["tab1_md1"]}_]')
    st.write(lang_dict['tab1_w2'])

    st.subheader(lang_dict["tab1_sh1"])
    st.write(lang_dict["tab1_w3"])
    #st.write(f'{lang_dict["tab1_w4_p1"]}"{name_tab_uploadF}"{lang_dict["tab1_w4_p2"]}')
    #st.write(f'{lang_dict["tab1_w5_p1"]}"{name_tab_XML}"{lang_dict["tab1_w5_p2"]}')
    st.write(f'- {lang_dict["tab1_w6_p1"]}"{name_tab_configuration}"{lang_dict["tab1_w6_p2"]}')
    st.write(f'- {lang_dict["tab1_w7_p1"]}"{name_tab_rename}"{lang_dict["tab1_w7_p2"]}')
    #st.write(f'{lang_dict["tab1_w8_p1"]}"{name_tab_configuration}"{lang_dict["tab1_w8_p2"]}"{name_tab_rename}"')

if __name__ == "__main__":
    main()

# to run the web app
# go inside folder PDFs_XML on the console(terminal)
# streamlit run Accueil.py