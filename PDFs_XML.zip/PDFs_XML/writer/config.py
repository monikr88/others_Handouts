from bo.section import Section
from tools import Configuration
import configparser

def write_config(section: Section, write=True): 
    """
    Writes a new entry (section) in config.ini.
    From Streamlit user input the info to read 
    a new type of PDF file. This values are 
    stored in the config.ini.

    Args:
        section (Section): object type Section write 
        (bool, optional): If only testing does not
        write the configuration. Defaults to True.

    Returns:
        configParse: returns a configuration object 
        to test renaming the sample files. Otherwise, 
        it returns True or False (error) if write = True.        
    """
    try:
        print ("Creating config section...")
        config_tmp = configparser.ConfigParser()
        config_tmp.add_section(section.key)
        config_tmp.set(section.key, 'XML_key_coordinates', section.XML_key_coordinates)
        config_tmp.set(section.key, 'company_name', section.company_name)
        config_tmp.set(section.key, 'pdf_title', section.pdf_title)
        config_tmp.set(section.key, 'XML_fields_coordinates', section.XML_fields_coordinates)
        config_tmp.set(section.key, 'XML_year_coordinates', section.XML_year_coordinates)
        config_tmp.set(section.key, 'XML_uncertainty_coordinates', section.XML_uncertainty_coordinates)
        config_tmp.set(section.key, 'fields_separators', section.fields_separators)
        config_tmp.set(section.key, 'fields_indexes', section.fields_indexes)
        config_tmp.set(section.key, 'fields_lens', section.fields_lens)
        
        if write:
            print ("Saving config section...")
            conf = Configuration()
            config = conf.get_config()
            if not config.has_option(section.key, 'company_name'): # Exists
                with open(conf.config_path, 'a', encoding="utf-8") as f:       
                    config_tmp.write(f)
                    print("New config section saved...")
                    return True
            else:
                print("Configuration exist!")
                return False
        else:
                return config_tmp # to test the new configuration before saving
    except Exception as e:
        print(f'Error: {e}')