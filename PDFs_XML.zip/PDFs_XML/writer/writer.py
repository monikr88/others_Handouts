from .config import write_config
from .pdf import tmp_write_local_files
from bo.section import Section
from bo.context import Context
import functools

from pathlib import Path

def save_config(key:str, key_coord:str, company_name:str, 
                pdf_title:str, fields:dict, year:str, 
                uncertainty:str, write=True):
    """
    Creates the object Section with all 
    inputs to save the configuration 

    Args:
        key (str): key of the section
        key_coord (str): XML coordinates of the key section
        company_name (str): Company's name to display at the beginning of the file name
        fields (dict): dictionary of fields to extract codes
        year (str): XML coodinates of the year
        write (bool, optional): When testing a new configuration, set it to False. Defaults to True.

    Returns:        
        configParse: returns a configuration object 
        to test renaming the sample files. Otherwise, 
        it returns True or False (error) if write = True.    
    """
    try:
        section = Section()
        section.key = key
        section.company_name = "\"" + company_name +"\""
        section.pdf_title = "\"" + pdf_title.replace("\"", "") + "\""
        section.XML_key_coordinates = "\"" + key_coord + "\""
        section.XML_year_coordinates = "\"" + year +"\""
        section.XML_uncertainty_coordinates =  "\"" + uncertainty +"\""
        
        # fields
        section.XML_fields_coordinates = "\"" + fields["field"] + "\""
        section.fields_separators = "\"" + fields["separator"] + "\""
        section.fields_indexes = fields["index"]
        section.fields_lens = fields["len"]
        
        return write_config(section, write)
    except Exception as e:
        print(f'Error: {e}')

def write_files(context:Context, output_path):
    """
    Reads the context to extract the files and calls
    the function to move and rename the files one by one. 

    Args:
        context (Context): object Context with files processed
    """
    try:
        print ("Saving files...")        
        if(context.pdfs!=None):     
            ##files = read_files_from_sharepoint() # not possible! 
            list(map(functools.partial(tmp_write_local_files,output_path), context.pdfs)) 
            print("Files saved...")
    except Exception as e:
            print(f'Error: {e}')