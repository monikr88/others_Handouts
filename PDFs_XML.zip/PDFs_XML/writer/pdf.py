import os
# from os import listdir
# from os.path import isfile, join
import shutil
import csv
from bo.file import File
from tools import Configuration
from datetime import date

sharepoint_path = None
output_file_name = None

def tmp_write_local_files(output_path, file:File): # Should be sharepoint
    """
    Moves files and changes the name of the PDFs from
    original path into \\_OUTPUTS\\HISTORY. Creates .csv 
    file with the list of new names.

    Args:
        file (File): file to rename and move into HISTORY    
    """
    try: 
        config = Configuration()
        output_file_name = config.get_output_setup()
        cwd = os.path.abspath(output_path + '\_OUTPUTs')
        if not os.path.exists(cwd):
            os.mkdir(cwd)
            
        if not os.path.exists(cwd + "\\HISTORY"):
            os.mkdir(cwd + "\\HISTORY")

        # Creates the file and adds the headers
        if not os.path.isfile(cwd + "\\" + output_file_name):
            #create file and headers    
            csv_file = open(cwd + "\\" + output_file_name,'w') # 'wb' = binary, 'w' = text
            writer = csv.writer(csv_file, delimiter=';', quoting=csv.QUOTE_MINIMAL) #, delimiter=';', quotechar='\'', quoting=csv.QUOTE_MINIMAL) # 
            writer.writerow(['précédent_nom', 'nouveau_nom', 'uncertainty'])
            csv_file.close()
        
        # if new file is not 'File not recognized'
        # moves files with new name into HISTORY
        # and writes into the .csv file
        if(file.new_name != "File not recognized."):
            if not os.path.exists(cwd + "\\HISTORY\\" + file.new_name):
                shutil.move(file.path, cwd + "\\HISTORY\\" + file.new_name, )
                #print(file.path, cwd + "\\HISTORY\\" + file.new_name)
            else:
                os.remove(file.path) # it's already been processed
                
            # New Line to register a new file name
            with open(cwd + "\\" + output_file_name, 'a', newline='') as csv_file:
                writer = csv.writer(csv_file, delimiter=';', quoting=csv.QUOTE_MINIMAL) # quotechar=''',
                writer.writerow([file.name, file.new_name, file.uncertainty])
                csv_file.close()    
        else:
            # list of files that the process could not change
            __report_errors(f"PATH: {file.path}, NEW NAME: {file.new_name}, ERROR: {file.error_message} \n", cwd)        
    except Exception as e:
        print(f'Error: {e}')
    
def __report_errors(error:str, path):
    """
    Creates an errors.txt file with the path and error 
    for each of the files that the process could not renamed.

    Args:
        error (str): path and error message of file that the process 
        could not find a configuration section to rename them
        path (str): _OUTPUTS folder sharepoint path 
    """
    try:
        txt_file = open(path + "\\errors_" + date.today().strftime("%d-%m-%Y") + ".txt",'a')
        txt_file.write(error)
    except Exception as e:
            print(f'Error: {e}')