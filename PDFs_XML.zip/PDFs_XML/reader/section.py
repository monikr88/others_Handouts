from bo.section import Section
from bo.context import Context
from tools import Configuration

def read_section_keys(config):
    """
    Reads the company's name and PDF title to present 
    them in the interface the exisiting configuration    
    
    Args:
        config (ConfigParser): Configuration object

    Returns:
        list: list with: company's name, key and PDF Title
        to present the existing configuration on the interface
        for user reference.
    """
    try:
        keys = []
        for sect in config._sections.keys(): # get_config        
            if not "system_conf" in sect:
                keys.append([config._sections[sect]["company_name"].replace("\"", ""), 
                            sect, 
                            config._sections[sect]["pdf_title"].replace("\"", "")])
        return keys
    except Exception as e:
        print(f'Error: {e}')

def read_sections(context: Context, config: Configuration):
    """
    Loads the entire configuration sections to assigned them
    to each file by using the key to match a file with a section

    Args:
        context (Context): to load the section's list attribute
        config (Configuration): to read the configuration file
    """
    try:
        print ("Loading sections...")
        # Find config section
        config_sect = config._sections
        
        if "system_conf" in config_sect:
            config_sect.pop('system_conf') # remove first section - system parameters
            
        for sect in config_sect.keys() :# get_config
            section = Section()
            #print(sect)
            section.__init__(key = sect
                            , XML_key_coordinates = config_sect[sect]["xml_key_coordinates"]
                            , company_name = config_sect[sect]["company_name"]
                            , pdf_title = config_sect[sect]["pdf_title"]
                            , XML_fields_coordinates = config_sect[sect]["xml_fields_coordinates"].replace(' ', '').split('","')
                            , XML_year_coordinates = config_sect[sect]["xml_year_coordinates"].replace('"','') 
                            , XML_uncertainty_coordinates = config_sect[sect]["xml_uncertainty_coordinates"].replace('"','') 
                            , fields_separators = config_sect[sect]["fields_separators"].replace('"','').split(',')
                            , fields_indexes = config_sect[sect]["fields_indexes"].split(',')
                            , fields_lens = config_sect[sect]["fields_lens"].split(',') if config_sect[sect]["fields_lens"].__contains__(',') else config_sect[sect]["fields_lens"])
            context.sections.append(section)
        
        print("Sections loaded...")
    except Exception as e:
        print(f'Error: {e}')