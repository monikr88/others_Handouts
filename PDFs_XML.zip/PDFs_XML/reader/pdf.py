# local file
import os
from pdfquery import PDFQuery
from bo.context import Context
from bo.file import File
from tools import Configuration

import time
#from .sharepoint import Sharepoint  

def get_XML(file):
    """
    Function to convert the PDF to XML

    Args:
        file (str): file path

    Returns:
        tree: gets the XML of PDF file
    """
    try:
        print("Reading file...")
        pdf = PDFQuery(file)
        pdf.load()
        print("XML ready!")
        # to find the coordinates to write in the confi.ini 
        return pdf.tree #.write(file + '.xml', pretty_print = True, ) # i need this in memory, no in a real file!
    except Exception as e:
        print(f'Error: {e}')
                
def __get_content_file(file):
    """
    Function to load the file into memory 
    inside an object type File

    Args:
        file (str): file path 

    Returns:
        File: object to store info related to the file
    """
    try:
        pdf_query = PDFQuery(file) 
        name = file
        if type(file) != str: # from Streamlit is type: streamlit.runtime.uploaded_file_manager.UploadedFile()
            name = file.name # so, we need to use file.name
            
        pdf_file = File(name = name.split('\\')[-1], # last value of path,
                        path = name,
                        pdf = pdf_query)
        return pdf_file
    except Exception as e:
        print(f'Error: {e}')
                
def __tmp_read_local_files(path:str): # Should be sharepoint
    """
    Reads local PDF files from folder and subfolders

    Args:
        path (str): file path

    Returns:
        list: list of pdfs located in the folder and subfolders
    """
    try:
        print("Reading local files")
        #cwd = path + f"\\METROLOGY EMEA QAE - Fiches d'interventions fournisseurs" # CHANGE THIS!
        cwd = path # from config.ini -> PDFs_path
        #cwd = os.getcwd() + '\\PDFs_XML\\data\\pdfs_inputs'
        #cwd = "C:\\Users\\rojasesm\\MANE\\METROLOGY EMEA QAE - Fiches d'interventions fournisseurs"
        print(cwd)
        folders = os.walk(cwd)
        onlypdfs= []
        for root, dirs, files in folders:
            #for file in files:
            if len(files) > 0 and not root.__contains__("_OUTPUTs"): #not files.startswith(".") and                
                files = ([os.path.join(root, file) for file in files
                            if os.path.isfile(os.path.join(root, file)) and 
                            (file.endswith(".pdf") or file.endswith(".PDF"))])
                onlypdfs.extend(files) # flat list, not a list of list
                
        if(len(onlypdfs)>0):
            print(f"{len(onlypdfs)} PDFs found!")
        else:
            print("No PDFs available")
                    
        return onlypdfs
    except Exception as e:
        print(f'Error: {e}')

def read_files(context: Context, config:Configuration, files = None, input_path=None):
    """
    Main function to read files

    Args:
        context (Context): to load the list of files into the context
        config (Configuration): to get the folder path to find the files
        files (_type_, optional): From Streamlit, files are already 
        loaded. Defaults to None.
    """
    try:
        print ("Loading files...")
        
         # get the start time
        start = time.time()
    
        if(files==None):
            ##files = read_files_from_sharepoint() # not possible!
            files = __tmp_read_local_files(input_path) # config['system_conf']['pdfs_path']
        
        for f in files:
            new_file = __get_content_file(f)
            context.pdfs.append(new_file)
            
        et = time.time()
        # get the execution time
        elapsed_time = et - start
        
        elapsed = f'Execution time: {float("{:.2f}".format(elapsed_time/60))} minutes'
        print("Elapse time reading_files", elapsed)
        
        print("Files loaded...")
    except Exception as e:
        print(f'Error: {e}')
        
# def read_files_from_sharepoint():
#     print("Openning connection sharepoint")
#     sharepoint_url = "https://manegroup.sharepoint.com/sites/EMEAQAEMETROLOGY"#/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FEMEAQAEMETROLOGY%2FShared%20Documents%2FESPACE%20METROLOGIE%2FFiches%20d%27interventions%20fournisseurs&viewid=4a6f3dfa%2Dbd6e%2D4de0%2Dbe78%2D219eae3cc5d1"

#     Sharepoint.connect_to_sharepoint(sharepoint_url)
#     #Sharepoint.connect_to_sharepoint_app_principal(sharepoint_url)
#     print("Sharepoint connection established")
    
#     print("Reading files from sharepoint")
#     print("Files read from sharepoint")