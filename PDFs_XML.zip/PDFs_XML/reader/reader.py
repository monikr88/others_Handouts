from .pdf import read_files
from .section import read_sections, read_section_keys
from tools import Configuration
from bo.context import Context

def read_context(config: Configuration, input_path):
    """
    Function to load local files and sections into the context

    Args:
        config (Configuration): config object

    Returns:
        Context: context to execute the process
    """
    try:
        context = Context()
        read_files(context, config, input_path=input_path)
        read_sections(context, config)
        return context
    except Exception as e:
        print(f' reader.py read_context Error: {e}')

def app_read_context(config: Configuration, pdfs):
    """
    Function to load the pdfs when using Streamlit Cloud. 
    It also load the sections into the context.

    Args:
        config (Configuration): config object
        pdfs (Streamllit_file): list of files uploaded 

    Returns:
        Context: context to execute the process
    """
    try:
        context = Context()
        read_files(context, None, pdfs)
        read_sections(context, config)
        return context
    except Exception as e:
        print(f'Error: {e}')

def app_read_section_keys(config):
    """
    Function to read the config.ini keys (sections)

    Args:
        config (ConfigParser): config object

    Returns:
        dict: keys of sections in config.ini
    """
    try:
        return read_section_keys(config)
    except Exception as e:
        print(f'Error: {e}')
 