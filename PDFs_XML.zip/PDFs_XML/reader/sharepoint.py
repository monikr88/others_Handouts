from dataclasses import dataclass
from office365.runtime.auth.authentication_context import AuthenticationContext # https://pypi.org/project/Office365-REST-Python-Client/
from office365.sharepoint.client_context import ClientContext
from office365.runtime.auth.user_credential import UserCredential
from office365.sharepoint.files.file import File 

app_principal = {
'client_id': '?',
'client_secret': '?',
}

@dataclass
class Sharepoint():

    def connect_to_sharepoint(sharepoint_url):
        ctx_auth = AuthenticationContext(sharepoint_url)

        ctx = ClientContext(sharepoint_url).with_credentials(UserCredential("monica.rojasespinoza@mane.com", "Mane2112."))
        
        # https://github.com/AzureAD/microsoft-authentication-library-for-python/wiki/Conditional-Access-and-Claims-Challenges
        # Note that there are certain conditional access policies that do not require user interaction to comply
        # with the policy. In such cases, it is recommended to use the acquire_token_silent method to handle 
        # the claims challenge that is returned and avoid prompting user interaction.

        #if ctx_auth.authenticate_request("monica.rojasespinoza@mane.com", "Mane2112."):
        #acquire_token_for_user("monica.rojasespinoza@mane.com", "Mane0211."):
        #ctx = ClientContext(sharepoint_url, ctx_auth)
        web = ctx.web
        ctx.load(web)
        ctx.execute_query()
        print('Authenticated into sharepoint as: ',web.properties['Title'])
        #else:
          #  print(ctx_auth.get_last_error())
        
        # return ctx
        pass
    
    # creating an app
    # https://manegroup.sharepoint.com/_layouts/15/ i dont have access
    # https://documentation.commvault.com/v11/essential/create_app_principal_for_sharepoint_online.html
    # https://learn.microsoft.com/en-us/sharepoint/dev/solution-guidance/security-apponly-azureacs
    def connect_to_sharepoint_app_principal(url_shrpt):
        ctx_auth = AuthenticationContext(url_shrpt)
        if ctx_auth.acquire_token_for_app(client_id=app_principal['client_id'], client_secret=app_principal['client_secret']):
            ctx = ClientContext(url_shrpt, ctx_auth)
            web = ctx.web
            ctx.load(web)
            ctx.execute_query()
            print('Authenticated into sharepoint app for: ',web.properties['Title'])
        else:
            print(ctx_auth.get_last_error())
            #sys.exit()

    def read_file_Sharepoint():
        """ 
        To read the files from Sharepoint
        """
        pass
    
    def write_Sharepoint():
        """ 
        To change the name of the file
        """
        pass