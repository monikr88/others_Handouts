"""
Files defining classes that will
 handle configuration sections
"""
from dataclasses import dataclass
from dataclasses import field

@dataclass
class Section:
    """
    Class that holds information on a section
    """
    key: str = field(default_factory = str)
    company_name: str = field(default_factory = str)
    pdf_title: str = field(default_factory=str)
    XML_key_coordinates: str = field(default_factory = str)
    XML_fields_coordinates: list[str] = field(default_factory = list)
    XML_year_coordinates: str = field(default_factory = str)
    XML_uncertainty_coordinates: str = field(default_factory = str)
    fields_separators: list[str] = field(default_factory = list)
    fields_indexes: list[str] = field(default_factory = list)
    fields_lens: list[str] = field(default_factory = list)