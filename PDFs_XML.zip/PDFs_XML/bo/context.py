"""
Files defining classes that will handle 
config detail and the several objects it holds
"""

from dataclasses import dataclass
from dataclasses import field
from .file import File
from .section import Section

@dataclass
class Context:
    pdfs: list[File] = field(default_factory = list)
    sections: list[Section] = field(default_factory = list)