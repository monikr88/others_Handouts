from dataclasses import dataclass
from dataclasses import field

from bo.section import Section
from pdfquery import PDFQuery

@dataclass
class File():
    """ 
    Stores file attributes
    """
    name: str = field(default_factory = str)
    path: str = field(default_factory = str)
    company: str = field(default_factory = str)
    section: Section = field(default_factory = Section)
    pdf: PDFQuery = field(default_factory = str)
    new_name: str = field(default_factory = str)
    error_message: str = field(default_factory = str)
    uncertainty: str = field(default_factory= str)
    
    def define_new_name(self):
        # format new_name -> delete extra spaces and delete space before last word and .pdf if exists
        tmp = ' '.join(self.new_name.split())
        self.new_name = tmp.replace(" .", ".").upper() #.replace("-", "").upper()
        
        # asign new name to the path, reemplacing the previous value 
        self.path.replace(self.name, self.new_name)