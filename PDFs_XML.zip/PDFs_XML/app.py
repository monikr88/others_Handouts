from tools import Configuration
from reader import read_context
from extraction import AssignmentSolver
from bo.context import Context

import pandas as pd
from reader import app_read_context

# def main() -> int:
#     """
#     Main function. For the automatic process.
#     Steps are, in order:
#     - read configuration file
#     - load context to run the process to rename the files 
#         - load sections on config file
#         - load the files 
#         - assign a key from config file each file
#     - run the extraction process
#         - for each file runs the extraction process
#     - rename files
#     """
#     print("app - Reading config.ini")
#     config = Configuration()
#     config = config.get_config()

#     # Loads data from inputs and fill context with it
#     print("app - Reading files")
#     context = read_context(config)
    
#     # Extraction
#     print("app - Starting extraction")
#     solver = AssignmentSolver(context)
#     solution = solver.process()
#     print("app - Extraction finished!")
    
#     # context.pdfs -> Type File with new_name
#     print(context.pdfs)
    
#     # Renaming - change file name   
#     print("app - Saving documents") 
#     write_files(context)
    
#     ## dump files name into csv -> Output: Table with new names
#     return solution

def load_bundle(locale):
        """
        This function loads the language file to
        translate labels into French or English

        Args:
            locale (str): Language selected

        Returns:
            dict: dictionary with labels in the selected language
        """
        # Load in the text bundle and filter by language locale.
        df = pd.read_csv("text_bundle.csv")
        df = df.query(f"locale == '{locale}'")
        # Create and return a dictionary of key/values.
        lang_dict = {df.key.to_list()[i]:df.value.to_list()[i] for i in range(len(df.key.to_list()))}
        return lang_dict
    
def simulation(pdfs, config:Configuration = None) -> dict:
    """
    This function creates the new file name without changing the file. 
    It is used to test a new configuration or an existing one.

    Args:
        pdfs (list): list of files uploaded
        trace (Configuration, optional): Configuration object which contains 
        the instructions to read the files, it can be a new configuration to 
        test. Defaults to None to use the existing configuration.

    Returns:
        dict: list of new file names
    """        
    # When not testing a new configuration
    if config == None:
            print("Reading config.ini")
            config = Configuration()
            config = config.get_config()
    
    # Loads data from inputs and fill context with it
    print("Reading files")
    context = app_read_context(config, pdfs)
    
    # Extraction
    print("Starting extraction")
    solver = AssignmentSolver(context)
    solution = solver.process()
    print("Extraction finished!")
    
    # context.pdfs -> List with Files containing new_name
    #print(context.pdfs)
    
    return solution
    
def main(input_path:str) -> dict:
    """
    Main function. Renames the files.
    Steps are, in order:
    - read configuration file
    - load context to run the process to rename the files 
        - load sections on config file
        - load the files 
        - assign a key from config file each file
    - run the extraction process
        - for each file runs the extraction process
        - rename files

    Args:    
        input_path (str): file's path

    Returns:
        dict: list of new file names
    """        
    print("Reading config.ini")
    config = Configuration()
    config = config.get_config()
    
    # Loads data from inputs and fill context with it
    print("Reading files")
    #print(input_path,  "\n", output_path)
    context = read_context(config, input_path = input_path)
    
    return context
    
def chunks(files, sections, output_path):
    """_summary_

    Args:
        files (_type_): _description_
        sections (_type_): _description_
        output_path (str): file's output path (renamed files)

    Returns:
        _type_: _description_
    """
    # Extraction
    print("Starting extraction")
    context2 = Context()        
    context2.sections = sections    
    context2.pdfs = files
    
    solver = AssignmentSolver(context2)
    solution = solver.process(output_path)
    
    print("Extraction finished!")
    
    return solution
        
if __name__ == '__main__':
    main()