import re
import math
from bo.section import Section
from bo.file import File

def extract_fields(file: File):
    """
    Main function to extract values from XML version,  
    in memory, of the PDF file. It saves the new name 
    on the object (file).

    Args:
        file (File): file to extract the values from

    Returns:
        dict: values extracted from the process before the 
        data cleaning process, to present them in the interface.
    """
    try:
        text_value_dict = {}
        new_line = '\n'
        if len(file.section.key) > 0:  
            print(f"Section key: {file.section.key}{new_line}File name: {file.name}{new_line}File type: {file.section.pdf_title}")
            fields, text_value_dict = __extract_fields_using_PDFQuery_BBOX(file.pdf, file.section)
            # Finding the year
            date  = __get_year(file.pdf, file.section.XML_year_coordinates, {})
            # Creating the new name
            file_name = ''.join([date, fields])
            if len(file_name) > 1:                
                # check the name, file_name must have a code 
                # format NN(N)-XXX(X) i.e. AE-5008, FIB-008
                print("file_name",file_name)
                regex= regex = "\\b[a-zA-Z]{2,3}-\d{3,4}"
                if(not re.search(regex, file_name)):
                    print("Cleaning process did not work. A new transformation "+
                    "of the rectangle's bounds is required.")
                    # Refine the solution
                    file_name, text_value_dict = __extract_fields_using_PDFQuery_BBOX(file.pdf, file.section, retransf_bounds=True)
                                    
                file.new_name = file.company + file_name + ".pdf"
                file.define_new_name()
                print(f"File NEW name: {file.new_name} {new_line} ------------------")
        elif len(file.new_name) == 0:
            file.new_name = "File not recognized." 
            file.error_message = "No configuration section assigned for this file."
            text_value_dict["message"] = file.error_message
            print(f"File name: {file.name}, Message: {file.error_message} {new_line} ------------------")
        
        names = {file.name: {"new_name": file.new_name, "extracted_values":{}}} # dict key original name, value new name ........names[file.name] = file.new_name
        names[file.name]["extracted_values"] = text_value_dict

        get_uncertainty(file, file.section.XML_uncertainty_coordinates)
        
        return names
    except Exception as e:
        print(f'extract_fields - Error: {e}')

def __get_year(pdf, coordinates:str, text_value_dict:dict):
    # Finding the year
    # rectangle = transform_bounds(pdf, coordinates)
    # date = pdf.pq(f'LTTextLineHorizontal:in_bbox("{rectangle}")').text()
    try:
        rectangle = transform_bounds(pdf, coordinates)
        date = pdf.pq(f'LTTextLineHorizontal:in_bbox("{rectangle}")').text()
        print(f"Date: {date}")
        if len(date) == 0:
            # If Empty maybe values are in Annots, not in TextLine
            date = __extract_fields_using_PDFQuery_Annots(pdf, coordinates)

        # REGEX to get only the year, 2 digits year.
        if(re.search("(-+)\d{2}$|\d{4}|(\/+)\d{2}$", date)): # 2023-11-13
            date = " " + re.search("\d{2}$", re.search("(?<!\d)\d{4}(?!\d)|(-+)\d{2}$|(\/+)\d{2}$", date).group()).group()
    
        return date 
    except Exception as e:
        print(f'__get_year - Error: {e}')
        
def __extract_fields_using_PDFQuery_BBOX(pdf, section:Section, retransf_bounds=False):
    """
    This function searchs for the values by QUERYING the file with the
    transformed (bigger rectangle) COORDINATES. After getting the
    value, it performs the DATA CLEANING PROCESS by using the separator,
    index, length keywords and some internal support functions.
    
    Steps to find the text are:
    - Transforms bounds (bigger rectangle)
    - Tries first with BBOX querying and cleans the output
    - If BBOX querying is empty, it tries with ANNOTS 
    (special case: Endress Certificat de bon fonctionnement, 
    file: ENDRESS CV 22 CBF390140362022102602_FIB8005.pdf)
    
    Finally, it finds the year following the same logic 
    and it joins all the outputs to create the new name.
    
    Args:
    - pdf (PDFQuery): file to apply the extraction process to.
    - section (Section): configuration section assigned to the file.
    
    Returns:
        tuple: returns the final name, and all the text extracted
        to find the values to be displayed on the interface,
        this is important when testing a new configuration
    """
    try:
        fields = ""
        text_value = {}
        for i in range(0,len(section.XML_fields_coordinates)): 
            coord = section.XML_fields_coordinates[i].replace('"', '')
            rectangle = transform_bounds(pdf, coord, retransf_bounds)
            print("text", pdf.pq(f'LTTextLineHorizontal:overlaps_bbox("{rectangle}")').text())
            # Using BBOX querying
            if len(pdf.pq(f'LTTextLineHorizontal:in_bbox("{rectangle}")').text()) != 0:
                text = pdf.pq(f'LTTextLineHorizontal:in_bbox("{rectangle}")').text()          
                print(f"Text in bbox: {text}")               
                text = pdf.pq(f'LTTextLineHorizontal:overlaps_bbox("{coord}")').text() 
                # does not work for all files, MC2 and  METTLER WQ-2060            
                print(f"Text in overlaps: {text}")               
                value = text 
                
                # Data cleaning process
                if len(section.fields_separators) > i and text.__contains__(section.fields_separators[i].replace("'", "")):
                    if len(section.fields_lens) > i:                    
                        value = __get_fields_by_position(text, section.fields_separators[i], section.fields_indexes[i], section.fields_lens[i])
                    else: 
                        value = __get_fields_by_position(text, section.fields_separators[i], section.fields_indexes[i])
                elif len(section.fields_lens) > i and section.fields_lens[i] != "":
                    value = value[:int(section.fields_lens[i])] # substring
                
                value = __add_N_dash(value)
                
                #print(f"Value ix_{i}: {value}")
                text_value[f"rectangle_{i}"] = text
                text_value[f"value_{i}"] = value
                text_value["key_config_section"] = section.key
                
                if len(value) > 20: 
                    # cleaning process did not work
                    print("TOO MANY CHARACTERS")
                    fields += " " + __extract_fields_using_PDFQuery_Annots(pdf, rectangle, section.fields_separators[i], section.fields_indexes[i])
                else:
                    fields += " " + value.upper().replace(' ', '')
            else:
                # Using ANNOT querying
                # If Empty, maybe, values are in Annots, not in TextLine
                value = __extract_fields_using_PDFQuery_Annots(pdf, rectangle, section.fields_separators[i], section.fields_indexes[i])
                
                text_value[f"Annotations_{i}"] = f"An_{i}"
                text_value[f"value_{i}"] = value
                print("value", value)
                value = __add_N_dash(value)
                
                fields += " " + value
        # end FOR!
        
        return fields, text_value
    
    except Exception as e:
        print(f'__extract_fields_using_PDFQuery_BBOX - Error: {e}')

def __add_N_dash(text:str):
    """
    Support function to add a - (N dash) in text, i.e:
     - AE5023 = AE-5023 
     - FIB8005 = FIB-8005
     - TT-1224 = TT-1224
     - AE5023BC = AE-5023BC
     
    Args:
        text (str): text to add an N dash before numbers

    Returns:
        str: text modified
    """
    try:
        # if value is compost of 2 to 3 characters and 3 to 4 numbers
        regex = "\\b[a-zA-Z]{2,3}\d{3,4}"
        if(re.search(regex, text)): # if text does not have -
            # add an N dash between characters and numbers
            regex = "\d+"
            numbers = re.search(regex, text).group()
            text = text.replace(numbers, "-"+numbers)
        return text
    except Exception as e:
        print(f'Error: {e}')

def __extract_fields_using_PDFQuery_Annots(pdf, rectangle, sep="", index=0):
    """
    Support function to find the values in case the coordinates correspond
    to <Annot> instead of <LTTextLineHorizontal> tag in the XML file.
    For this case, text is in the "V" value attribute of <Annot> tag.

    Args:
        pdf (PDFQuery): file to apply the extraction process to.
        rectangle (str): coordinates transformed to get more text
        sep (str, optional): separator to split text. Defaults to "".
        index (int, optional): index to get after split. Defaults to 0.

    Returns:
        str: values extracted
    """
    try:
        # get all Annots to find the value. Case ENDRESS FIB8005 file
        annots = pdf.pq('Annot')
                    
        values = ""          
        for a in range(0, len(annots)):
            if annots[a].attrib["bbox"].replace('[', '').replace(']', '').replace(' ', '') == rectangle.replace('"','').replace(" ", ""):
                    value = annots[a].attrib['V'] 
                    # print(f"Value from Annots: {value}")
                    if len(sep) != 0 and value.__contains__(sep):
                        values += " " + __get_fields_by_position(annots[a].attrib['V'], sep, index)
                        break
                    else:
                        values += annots[a].attrib['V'].upper().replace(' ', '')
        return values
    
    except Exception as e:
        print(f'Error: {e}')

def __get_fields_by_position(field, separator, position, f_len = ""):
    """
    Support function to get values in a specific position after splitting 
    the extracted text. This is part of the data cleaning process.

    Args:
        field (str): text to split
        separator (str): separator to use to split the text
        position (str): position to return after the splitting
        f_len (str, optional): Amoung of characteres to get from 
        the specific position. Defaults to "".

    Returns:
        str: cleaned text, i.e: AE0502
    """
    try:
        fields = []
        if separator == '' or separator == "' '":
            fields = field.split()
        elif field.__contains__(separator.replace("'", '')):
            fields = field.split(separator.replace("'", ""))
        
        index2 = position   
        if position.__contains__('-'):
            index2 = position.replace("'",'').split('-')
        elif position.__contains__("last"):
            index2 = len(fields)
        elif position == '': # take the first value
            index2 = 1
            
        value = ""
        
        if type(index2) == list:
            # for examples like index=2-3 (config.ini), the value is in more than 1 position in the list (split with -)
            for ix in index2: 
                value += fields[int(ix)-1] if f_len == "" else fields[int(ix)-1][:int(f_len)] # substring
        else:
            value = fields[int(index2)-1] if f_len == "" else fields[int(index2)-1][:int(f_len)]
        
        return value.upper().replace(' ', '')
    
    except Exception as e:
        print(f'Error: {e}')

def transform_bounds(pdf, bounderies, key=False):
    """
    Function to extend the given coordinates (config.ini). It creates 
    a bigger rectangle to extract more text, for the process to work
    for each PDF file, even for reports from the same company. It
    applies a different logic to the coordinates of the section name 
    (config.ini, i.e [Anton Paar]).

    Args:
        pdf (PDFQuery): file to extract the text from.
        bounderies (str): given coordinates from config.ini
        title (bool, optional): If coordinates are for section 
        name in the configuration. Defaults to False.

    Returns:
        str: coordinates transformed into a bigger rectangle
    """
    try:
        b = bounderies.split(',')
        if key: 
            # It works to find the key and to redefine the solution, for example 
            # FR0841-121-072523-ACC_1121093894_PG4002-SDR_V MANE FILS  WQ2060 SCRAPPED.pdf
            # if we are looking for the section key to macth the 
            # configuration file attribute xml_key_coordinates
            for i in range(0, len(b)):
                if i < 2:
                    b[i] = str(math.floor(float(b[i].replace("\"", "")) /100.0) *100.0) #f.replace(b, str(float(f.split(',')[2])+100))
                else : 
                    b[i] = str(math.ceil(float(b[i].replace("\"", "")) /100.0) *100.0)
                
            return ','.join(b) 
        else:
            # to apply to the rest of the coordinates (xml_fields_coordinates, xml_year_coordinates)
            if __extract_fields_using_PDFQuery_Annots(pdf, bounderies) == "": 
                for i in range(0, len(b)):
                    if i == 0: # X0
                        b[i] = str(math.floor(float(b[i].replace("\"", "")) /100.0) *100.0) #f.replace(b, str(float(f.split(',')[2])+100))
                    elif i == 1: # Y0
                        b[i] = str(float(b[i].replace("\"", ""))  - 10)
                    elif i == 2: # X1
                        b[i] = str(float(b[i].replace("\"", ""))  + 10)
                    else: # Y1
                        b[i] = str(math.ceil(float(b[i].replace("\"", "")) /100.0) *100.0)
                return ','.join(b) #str(b).replace('[', '').replace(']', '') #b
            else: 
                return bounderies
    
    except Exception as e:
        print(f'Error: {e}')
        
def get_uncertainty(file:File, coordinates):
    try:
        #coordinates = "293.99, 193.945, 325.088, 201.824"
        if len(coordinates) > 0:
            rectangle = transform_bounds(file.pdf, coordinates)
            value = file.pdf.pq(f'LTTextLineHorizontal:in_bbox("{rectangle}")').text()
            #print(value)
            if not value.upper().__contains__("AS FOUND"): #and not value.upper().__contains__("EXEMPLES"):
                #print(pdf.pq(f'LTTextLineHorizontal:overlaps_bbox("{rectangle}")').text())
                file.uncertainty = value.split()[-1] 
                if not value.__contains__("%"):
                    file.uncertainty = "N/A" # if value does no contain % return N/A              
                #dicti = file.pdf.pq(':contains("Examples")'),#, lambda match: int(match.text()[-5:-1])),
            else:
                table = value.split('As Found')
                #print("table", table[1])
                subtable = table[1].split()
                if len(subtable) < 11:
                    file.uncertainty = ""
                else:
                    value = table[1].split()[11]
                    file.uncertainty = value 
                    if not value.__contains__("%"):
                        file.uncertainty = "N/A" # if value does no contain % return N/A
    except Exception as e:
        print(f'get_uncertainty - Error: {e}')
        