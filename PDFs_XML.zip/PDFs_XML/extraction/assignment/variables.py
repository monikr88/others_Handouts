from bo import Context

def _build_assignment_variables(context: Context) -> dict: 
    """
    Creates assignment variables (which tie a file and a section-configuration types)
    """
    
    return {
        (file.name, section.key): section.XML_key_coordinates
         for file in context.pdfs
         for section in context.sections
    }

# List of variables
_VARIABLES_TO_BUILD = [
    ('assignment', _build_assignment_variables)
]

def build_variables(context: Context) -> dict:
    """
    Creates the variables tha can be precreated
    (i.e. not the slack or activation variables)
    """
    return {
        name: build_function(context)
        for name, build_function in _VARIABLES_TO_BUILD
    }
