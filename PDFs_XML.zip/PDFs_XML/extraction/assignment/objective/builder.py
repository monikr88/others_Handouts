from extraction.assignment.extraction import extract_fields
from bo.context import Context
from writer import write_files

def builder():
    pass

def process(
        context: Context,
        output_path=None
    ) -> list:
    """
        Builds the process to read each file and to present their new name
    """
    print('PDF: process started.')
    solution = (list(map(extract_fields, context.pdfs))) # applies function extract_fields to each file
    # Renaming - change file name   
    print("Saving documents")
    if(output_path != None): 
        write_files(context, output_path)
    
    print('PDF: process finished.')
    
    return solution