from .constraints import build_constraints
from .objective import process
from .variables import build_variables
from bo.context import Context

class AssignmentSolver():
    def __init__(self, context: Context) -> None:
        """
        Initializes assignment solver
        """  
        try:      
            self._context: Context = context
        except Exception as e:
            print(f'Error: {e}')

    def process(self, output_path=None) -> list:
        """
        Builds the process to extract the values
        """
        try:
            print('Solver: build variables ...')
            self.variables_map: dict = build_variables(self._context)
            
            print('Solver: build constraints ...')
            build_constraints(self.variables_map, self._context)
            self.variables_map.clear()
            del self.variables_map
                
            print('Solver: processing the context ...')
            solution = process(self._context, output_path)

            print('Solver: problem solved.')
            return solution
        except Exception as e:
                print(f'Error: {e}')
