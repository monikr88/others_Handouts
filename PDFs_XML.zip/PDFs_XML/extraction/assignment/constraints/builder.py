"""
List and builds the given contraints
(list consists of the function that actually builds the constraints)
"""
from .assignments import _build_one_section_type_per_file
from bo import Context

_CONSTRAINTS_TO_BUILD = [
    ('assign_section_to_one_file', _build_one_section_type_per_file),
]

def build_constraints(variables_map: dict, context: Context):
    for constraint_name, build_function in _CONSTRAINTS_TO_BUILD:
        build_function(variables_map, context)