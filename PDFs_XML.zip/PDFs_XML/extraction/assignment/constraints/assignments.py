"""
In this file, functions to create constraints
on assigning configuration sections to files types
"""
from extraction.assignment.extraction import transform_bounds
from bo import Context
import time

def _build_one_section_type_per_file(
        variables_map: dict,
        context: Context
        ) -> None:
    """
    Creates constraints that ensures files are assigned to only one configuration section
    """
    try:
        print('Assigning section - file type assignment constraints ...')       
        
         # get the start time
        start = time.time()        
        assignment_map = variables_map['assignment']

        for file in context.pdfs:
            file.pdf.load()            
            for sect in context.sections:
                section_title = assignment_map[(file.name, sect.key)]
                
                bounderies = transform_bounds(file.pdf, section_title, key = True)
                comp_name = file.pdf.pq('LTTextLineHorizontal:in_bbox("' + bounderies + '")').text() 
                text = file.pdf.pq(":contains(" + sect.pdf_title + ")").text()
                #print(text)
                print("TITLE:", sect.pdf_title)
                report_exist_in_config = len(file.pdf.pq(":contains(" + sect.pdf_title + ")"))
                #print(report_exist_in_config)
                
                print("NAME",comp_name)
                print("KEY", sect.key)
                print("res", comp_name.__contains__(sect.key))
                print("report", report_exist_in_config)
                if(comp_name.__contains__(sect.key) ): #and report_exist_in_config > 0):
                    print(f"Assigning section: \"{sect.key}\" to file: \"{file.name}\". File type {sect.pdf_title}")
                    file.section = sect
                    file.company = sect.company_name.replace("\"", "")
                    file.pdf.file.close()
                    break
            
            if(file.section == None): 
                file.pdf.file.close()   
                
        et = time.time()
        # get the execution time
        elapsed_time = et - start        
        elapsed = f'Execution time: {float("{:.2f}".format(elapsed_time/60))} minutes'
        print("ELAPSED TIME IN _build_one_section_type_per_file", elapsed)   
    except Exception as e:
            print(f'Error: {e}')